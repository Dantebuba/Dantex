/*CMD
  command: /BabaSonuc
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

try {
  let babaData = JSON.parse(content);
  User.setProperty("babaSonuc", babaData, "json");
} catch (e) {
  Bot.sendMessage("❌ Baba verisi alınamadı.");
}
Bot.runCommand("/tcSonuc");
