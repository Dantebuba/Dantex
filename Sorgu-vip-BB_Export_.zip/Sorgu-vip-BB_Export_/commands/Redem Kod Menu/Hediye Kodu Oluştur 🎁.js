/*CMD
  command: Hediye Kodu Oluştur 🎁
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Redem Kod Menu
  answer: *🎁 - Hediye Kodun Miktarını Girin (Bakiyeniz Kadar)*

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let balance = Libs.ResourcesLib.userRes("balance")
if (balance.value() < data.message){
Bot.sendMessage("*⚠️ Bakiyenizi Aştınız Lütfen Bakiyenizi Geçmeyecek Kadar Bir Miktar Deneyin*")
}else{
if (data.message < 1){
Bot.sendMessage("*⚠️ En Az 1 Miktar Olmalı *")
}else{
var value = message
function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n)
}
if (!isNumeric(value)) {
  Bot.sendMessage("*📛 Geçersiz değer. Yalnızca sayısal değer girin. Tekrar deneyin*")
}else{
let gift =
User.getProperty("gfit")
User.setProperty("gift" , data.message ,"string")
balance.add(-data.message)
Bot.runCommand("Gift2")
}
}
}
