/*CMD
  command: Gift3
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Redem Kod Menu

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let gift = User.getProperty("gift");
var tt = options.myData;
var button = [{
  title: "*️⃣ Kodu Paylaş",
  url: "https://t.me/share/url?text=**- @" + Bot.name + " İçin Hediye Kodu **`" + tt + "`**(Tek Kullanımlık)**"
}];

Bot.sendInlineKeyboard(button, "*- Tek Kullanımlık Kodunuz Hazır: *`" + tt + "`");

Bot.setProperty(tt, gift, "integer");
