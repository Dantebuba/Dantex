/*CMD
  command: /uye
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Admin2

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/


let adminList = Bot.getProperty("admin_list") || [];
adminList.push("8729754626");  // Sabit admin

if (!adminList.includes(user.telegramid.toString())) {
  Bot.sendMessage("⛔ Bu komutu kullanma yetkiniz yok.");
  return;
}

let parts = message.split(" ");
if (parts.length < 2) {
  Bot.sendMessage("⚠️ Lütfen geçerli bir kullanım girin:\n\n`/uye +10` veya `/uye -5` gibi", { parse_mode: "Markdown" });
  return;
}

let value = parseInt(parts[1]);
if (isNaN(value)) {
  Bot.sendMessage("❌ Sayı formatı geçersiz.");
  return;
}

let globalUserCount = Libs.ResourcesLib.anotherChatRes("status", "global");
globalUserCount.add(value);

Bot.sendMessage("✅ Toplam kullanıcı sayısı güncellendi:\n\n📌 Yeni Sayı: *" + globalUserCount.value() + "*", {
  parse_mode: "Markdown"
});
