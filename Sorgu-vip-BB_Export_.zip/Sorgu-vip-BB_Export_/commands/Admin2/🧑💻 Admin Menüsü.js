/*CMD
  command: 🧑‍💻 Admin Menüsü
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Admin2

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: /admins
  group: 
CMD*/

if (request.data) {
  var message_id = request.message.message_id;
  var chat_id = request.message.chat.id;

  Api.deleteMessage({
    chat_id: chat_id,
    message_id: message_id
  });
}

let anaAdmin = 8729754626;
let adminList = Bot.getProperty("admin_list") || [];
let kullaniciId = user.telegramid;

if (kullaniciId == anaAdmin || adminList.includes(kullaniciId.toString())) {
  Bot.sendMessage("🔐 Erişim Onaylandı");

  Bot.sendKeyboard(
    "Mesaj Gönder \nK. Banla 🚫, K. Banını Aç ⭕\n⚔️ Diğer (/) Komutları\n🏘️ Ana Menü",
    "*👋 Admin Menüsüne Hoş Geldin*"
  );
} else {
  Bot.sendMessage("*🚫 Bu bölüme erişim izniniz yok.*", { parse_mode: "Markdown" });
}
