/*CMD
  command: /addadmin
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Admin2

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

// SADECE ANA ADMIN KULLANABİLİR
if (user.telegramid != 8729754626) {
  Bot.sendMessage("⛔ Bu komutu kullanma yetkiniz yok.");
  return;
}

let args = message.split(" ");
if (args.length < 2) {
  Bot.sendMessage("⚠️ Lütfen kullanıcı ID veya ID'leri girin.\n\nÖrnek:\n`/addadmin 123456789`\n`/addadmin 123,456,789`", { parse_mode: "Markdown" });
  return;
}

let yeniAdminler = args[1].split(",").map(id => id.trim()).filter(Boolean);
let mevcutAdminler = Bot.getProperty("admin_list") || [];
for (let i = 0; i < yeniAdminler.length; i++) {
  let id = yeniAdminler[i];
  if (!mevcutAdminler.includes(id)) {
    mevcutAdminler.push(id);
  }
}
Bot.setProperty("admin_list", mevcutAdminler, "json");

Bot.sendMessage("✅ *Admin listesine eklendi:*\n\n`" + yeniAdminler.join("`, `") + "`", { parse_mode: "Markdown" });
