/*CMD
  command: ⚔️ Diğer (/) Komutları
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Admin2

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

Bot.sendMessage(
  "*▪️/addadmin {Chat ID} - Admin Ekler Sadece Baş Admin Kullanabilir\n▫️/adminlist {Chat ID} - Adminleri Listeler Sadece Baş Admin Kullanabilir\n▪️/deladmin {Chat ID} - Admin Siler Sadece Baş Admin Kullanabilir\n▫️/duyuru {mesaj} Bütün Bot Kullanıcılarına Mesaj Giderir\n▪️/bakim on/off - Botu Bakıma Ekler Çıkarır*",
  {
    parse_mode: "Markdown"
  }
)

