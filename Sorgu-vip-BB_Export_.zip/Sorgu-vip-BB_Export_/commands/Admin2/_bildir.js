/*CMD
  command: /bildir
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Admin2
  answer: 


  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let tgid = User.getProperty("id")
let msag = message
let msg = "💬 Adminden Mesaj Var \n➖➖➖➖➖➖➖➖➖➖➖\n\n" + msag
Bot.sendMessageToChatWithId(tgid, msg)
Bot.sendMessage("*✅Kullanıcıya Gönderildi\n\n*" + msg)
