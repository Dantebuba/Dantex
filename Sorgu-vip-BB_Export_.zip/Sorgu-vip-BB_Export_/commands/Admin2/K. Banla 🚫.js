/*CMD
  command: K. Banla 🚫
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Admin2
  answer: *🚫 - Banlamak İstediğiniz Kullanıcının İd'sini Girin*

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let adminID = 8729754626; // Admin Telegram ID

if (user.telegramid != adminID) {
  return Bot.sendMessage("⛔ Bu komutu kullanma yetkin yok.");
}

// Gelen mesaj bir kullanıcı ID'si mi kontrol et
let targetId = message.trim();

if (!/^\d+$/.test(targetId)) {
  return Bot.sendMessage("⚠️ Geçerli bir Telegram ID girin. Sadece rakamlardan oluşmalıdır.");
}

// Banla
Bot.setProperty("Ban_" + targetId, "banned", "string");
Bot.sendMessage("✅ Kullanıcı başarıyla banlandı.\n\nID: `" + targetId + "`", { parse_mode: "Markdown" });

// Kullanıcıya bilgi gönder
Bot.sendMessageToChatWithId(targetId, "🚫 *Erişiminiz engellendi.*", { parse_mode: "Markdown" });
