/*CMD
  command: /la
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Admin2
  answer: g

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var admin = "8729754626" 

if (user.telegramid == admin) {
  BBAdmin.installBot({
    email: message,
    bot_id: bot.id
  });
  Bot.sendMessage("- " + message);
} else {
  Bot.sendMessage("x");
}
