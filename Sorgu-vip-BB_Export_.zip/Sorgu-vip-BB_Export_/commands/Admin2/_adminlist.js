/*CMD
  command: /adminlist
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Admin2

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

if (user.telegramid != 8729754626) {
  Bot.sendMessage("⛔ Bu komutu kullanma yetkiniz yok.");
  return;
}
let adminList = Bot.getProperty("admin_list") || [];

if (adminList.length === 0) {
  Bot.sendMessage("⚠️ Admin listesi boş.");
} else {
  Bot.sendMessage("👑 *Admin Listesi:*\n\n`" + adminList.join("`, `") + "`", { parse_mode: "Markdown" });
}
