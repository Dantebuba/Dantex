/*CMD
  command: /bakim
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Admin2

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

// Admin yetki kontrolü
let anaAdmin = 8729754626;
let adminList = Bot.getProperty("admin_list") || [];
let kullaniciId = user.telegramid;

if (kullaniciId != anaAdmin && !adminList.includes(kullaniciId.toString())) {
  Bot.sendMessage("⛔ Bu komutu kullanma yetkiniz yok.");
  return;
}
let args = message.split(" ");
if (args.length < 2) {
  Bot.sendMessage("⚠️ Lütfen şu şekilde kullanın:\n\n`/bakim on`\n`/bakim off`", { parse_mode: "Markdown" });
  return;
}

let durum = args[1].toLowerCase();

if (durum === "on") {
  Bot.setProperty("bakimStat", true, "boolean");
  Bot.sendMessage("🔧 *Bot bakım moduna alındı.*", { parse_mode: "Markdown" });
} else if (durum === "off") {
  Bot.setProperty("bakimStat", false, "boolean");
  Bot.sendMessage("✅ *Bot artık aktif.*", { parse_mode: "Markdown" });
} else {
  Bot.sendMessage("❗ Geçersiz komut. `on` veya `off` yazmalısınız.", { parse_mode: "Markdown" });
}
