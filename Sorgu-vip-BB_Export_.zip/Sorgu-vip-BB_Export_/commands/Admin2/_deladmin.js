/*CMD
  command: /deladmin
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Admin2

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

if (user.telegramid != 8729754626) {
  Bot.sendMessage("⛔ Bu komutu kullanma yetkiniz yok.");
  return;
}

let args = message.split(" ");
if (args.length < 2) {
  Bot.sendMessage("⚠️ Lütfen silmek istediğiniz admin ID veya ID'leri yazın.\n\nÖrnek:\n`/deladmin 12345`\n`/deladmin 123,456,789`", { parse_mode: "Markdown" });
  return;
}

let silinecekIDler = args[1].split(",").map(id => id.trim()).filter(Boolean);
let mevcutAdminler = Bot.getProperty("admin_list") || [];

let guncelAdminler = mevcutAdminler.filter(id => !silinecekIDler.includes(id));

Bot.setProperty("admin_list", guncelAdminler, "json");
Bot.sendMessage("🗑️ *Silinen Admin ID'leri:*\n\n`" + silinecekIDler.join("`, `") + "`", { parse_mode: "Markdown" });
