/*CMD
  command: K. Banını Aç ⭕
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Admin2
  answer: *⭕ - Banını Açmak İstediğiniz Kullanıcının İd'sini Girin*

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let adminID = 8729754626; // Admin Telegram ID

if (user.telegramid != adminID) {
  return Bot.sendMessage("⛔ Bu komutu kullanma yetkin yok.");
}

let targetId = message.trim();

if (!/^\d+$/.test(targetId)) {
  return Bot.sendMessage("⚠️ Geçerli bir Telegram ID girin. Sadece rakamlardan oluşmalıdır.");
}

Bot.setProperty("Ban_" + targetId, null);

Bot.sendMessage("✅ Kullanıcı başarıyla unbanlandı.\n\nID: `" + targetId + "`", { parse_mode: "Markdown" });
Bot.sendMessageToChatWithId(targetId, "✅ *Erişiminiz tekrar açıldı.*", { parse_mode: "Markdown" });
