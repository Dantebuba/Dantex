/*CMD
  command: /duyuru
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Admin2

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

// SADECE ANA ADMIN + admin_list erişebilir
let anaAdmin = 8729754626;
let adminList = Bot.getProperty("admin_list") || [];

if (user.telegramid != anaAdmin && !adminList.includes(user.telegramid.toString())) {
  Bot.sendMessage("⛔ Bu komutu kullanma yetkiniz yok.");
  return;
}
let args = message.split(" ");
if (args.length < 2) {
  Bot.sendMessage("⚠️ Lütfen bir duyuru mesajı yazın:\n\n`/duyuru mesajınız`", { parse_mode: "Markdown" });
  return;
}

let duyuruMesaji = message.substring(8);
let users = Bot.getAllUsers();

for (let i = 0; i < users.length; i++) {
  Bot.sendMessageToChatWithId(users[i].telegramid, "📢 *Duyuru:*\n\n" + duyuruMesaji, { parse_mode: "Markdown" });
}

Bot.sendMessage("✅ *Duyuru tüm kullanıcılara gönderildi!*", { parse_mode: "Markdown" });
