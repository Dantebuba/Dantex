/*CMD
  command: Mesaj Gönder ☎️
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Admin2
  answer: * 🆔 - Kullanıcı İd'sini Gir*

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var adminId = 8729754626;

var admin = Bot.getProperty("botadmin" + user.telegramid);
if (user.telegramid == admin || user.telegramid == adminId) { 
  let msg = message;
  User.setProperty("id", msg, "integer");
  Bot.sendMessage("*Şimdi Kullanıcı İçin Mesajınızı Yazın*");
  Bot.runCommand("/bildir");
} else {
  Bot.sendMessage("*Sen bir Yönetici değilsin*");
}
