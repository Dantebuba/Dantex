/*CMD
  command: /newmenu
  help: 
  need_reply: false
  auto_retry_time: 
  folder: New Web App

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var userStat = User.getProperty("userStatus");
if (!userStat || userStat == "left") {
  Bot.runCommand("/start");
  return;
}
if (
  userStat == "member" ||
  userStat == "administrator" ||
  userStat == "creator"
) {
  if (request && request.data) {
    Api.deleteMessage({
      chat_id: request.message.chat.id,
      message_id: request.message.message_id
    });
  }

  var AppURL = WebApp.getUrl({ command: "index" });
  var enc = WebApp.getUrl({ command: "index1" });


  Api.sendMessage({
    chat_id: user.telegramid,
    text:
      "🍀 <b>Merhaba Dostum</b> <a href='tg://user?id=" +
      user.telegramid +
      "'>" +
      user.first_name +
      "</a><b> (<code>"+ user.telegramid +"</code>) Sxrgu botuna hoş geldin istediğin işlemi seçip kullanabilirsin</b>",
    parse_mode: "html",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "㊙️ Panel Giriş", web_app: { url: panel } }
        ]
      ]
    }
  });
}
