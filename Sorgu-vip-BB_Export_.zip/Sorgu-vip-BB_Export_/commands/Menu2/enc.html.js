/*CMD
  command: enc.html
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu2

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Base64 Kodlama ve Çözme Aracı</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
        
        body {
            background-color: #f8f9fa;
            color: #1a1a1a;
            line-height: 1.6;
            padding: 20px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        
        .container {
            width: 100%;
            max-width: 800px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            margin: 20px auto;
        }
        
        h1 {
            text-align: center;
            margin-bottom: 1.5rem;
            color: #1a1a1a;
            font-weight: 600;
        }
        
        .description {
            text-align: center;
            margin-bottom: 2rem;
            color: #666;
        }
        
        .input-group, .output-group {
            margin-bottom: 1.5rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #333;
        }
        
        textarea {
            width: 100%;
            min-height: 120px;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            resize: vertical;
            transition: border-color 0.2s;
        }
        
        textarea:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.1);
        }
        
        .buttons {
            display: flex;
            gap: 12px;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }
        
        button {
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .encode-btn {
            background-color: #007bff;
            color: white;
            flex: 1;
        }
        
        .encode-btn:hover {
            background-color: #0069d9;
        }
        
        .decode-btn {
            background-color: #28a745;
            color: white;
            flex: 1;
        }
        
        .decode-btn:hover {
            background-color: #218838;
        }
        
        .copy-btn {
            background-color: #6c757d;
            color: white;
            flex: 1;
        }
        
        .copy-btn:hover {
            background-color: #5a6268;
        }
        
        .clear-btn {
            background-color: #dc3545;
            color: white;
            flex: 1;
        }
        
        .clear-btn:hover {
            background-color: #c82333;
        }
        
        .alert {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 1rem;
            display: none;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        @media (max-width: 600px) {
            .buttons {
                flex-direction: column;
            }
            
            button {
                width: 100%;
            }
            
            .container {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Base64 Kodlama ve Çözme Aracı</h1>
        <p class="description">Metni Base64 formatına dönüştürün veya Base64 kodunu çözün</p>
        
        <div class="alert alert-error" id="errorAlert"></div>
        <div class="alert alert-success" id="successAlert"></div>
        
        <div class="input-group">
            <label for="inputText">Giriş Metni:</label>
            <textarea id="inputText" placeholder="Kodlamak veya çözmek istediğiniz metni buraya yazın..."></textarea>
        </div>
        
        <div class="buttons">
            <button class="encode-btn" onclick="encodeBase64()">Base64 Kodla</button>
            <button class="decode-btn" onclick="decodeBase64()">Base64 Çöz</button>
            <button class="copy-btn" onclick="copyOutput()">Çıktıyı Kopyala</button>
            <button class="clear-btn" onclick="clearAll()">Temizle</button>
        </div>
        
        <div class="output-group">
            <label for="outputText">Çıktı Metni:</label>
            <textarea id="outputText" readonly placeholder="Sonuç burada görünecek..."></textarea>
        </div>
    </div>

    <script>
        function showAlert(elementId, message) {
            const alert = document.getElementById(elementId);
            alert.textContent = message;
            alert.style.display = 'block';
            
            // 5 saniye sonra uyarıyı gizle
            setTimeout(() => {
                alert.style.display = 'none';
            }, 5000);
        }
        
        function encodeBase64() {
            const inputText = document.getElementById('inputText').value;
            if (!inputText) {
                showAlert('errorAlert', 'Lütfen kodlanacak metni girin.');
                return;
            }
            
            try {
                const encoded = btoa(unescape(encodeURIComponent(inputText)));
                document.getElementById('outputText').value = encoded;
                showAlert('successAlert', 'Metin başarıyla Base64 formatına kodlandı.');
            } catch (error) {
                showAlert('errorAlert', 'Kodlama sırasında bir hata oluştu: ' + error.message);
            }
        }
        
        function decodeBase64() {
            const inputText = document.getElementById('inputText').value;
            if (!inputText) {
                showAlert('errorAlert', 'Lütfen çözülecek Base64 kodunu girin.');
                return;
            }
            
            try {
                const decoded = decodeURIComponent(escape(atob(inputText)));
                document.getElementById('outputText').value = decoded;
                showAlert('successAlert', 'Base64 kodu başarıyla çözüldü.');
            } catch (error) {
                showAlert('errorAlert', 'Çözme sırasında bir hata oluştu. Geçerli bir Base64 kodu girdiğinizden emin olun.');
            }
        }
        
        function copyOutput() {
            const outputText = document.getElementById('outputText');
            if (!outputText.value) {
                showAlert('errorAlert', 'Kopyalanacak bir çıktı bulunamadı.');
                return;
            }
            
            outputText.select();
            document.execCommand('copy');
            showAlert('successAlert', 'Çıktı panoya kopyalandı.');
        }
        
        function clearAll() {
            document.getElementById('inputText').value = '';
            document.getElementById('outputText').value = '';
            document.getElementById('errorAlert').style.display = 'none';
            document.getElementById('successAlert').style.display = 'none';
        }
    </script>
</body>
</html>
