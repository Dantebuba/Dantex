/*CMD
  command: index
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu2

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

WebApp.render({
  template: "index.html"
});
