/*CMD
  command: /menu
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu2

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var userStat = User.getProperty("userStatus");
if (!userStat || userStat == "left") {
  Bot.runCommand("/start");
  return;
}
if (
  userStat == "member" ||
  userStat == "administrator" ||
  userStat == "creator"
) {
  if (request && request.data) {
    Api.deleteMessage({
      chat_id: request.message.chat.id,
      message_id: request.message.message_id
    });
  }
  var AppURL = WebApp.getUrl({ command: "index" });
  var enc = WebApp.getUrl({ command: "index1" });
  Api.sendMessage({
    chat_id: user.telegramid,
    text:
      "🍀 <b>Merhaba Dostum</b> <a href='tg://user?id=" +
      user.telegramid +
      "'>" +
      user.first_name +
      "</a><b> (<code>"+ user.telegramid +"</code>) Sxrgu botuna hoş geldin istediğin işlemi seçip kullanabilirsin</b>",
    parse_mode: "html",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "🔮 Ad Soyad (bakım)", callback_data: "/bak" }
        ],
        [
          { text: "🎅 Baba Sorgu", callback_data: "/baba" },
          { text: "🤱 Anne Sorgu", callback_data: "/anne" }
        ],
        [
          { text: "💑 Kardeş Sorgu", callback_data: "/kar" },
          { text: "👦 Çocuk Sorgu", callback_data: "/coc" }
        ],
        [
          { text: "👤 Tc Sorgu", callback_data: "/tc" },
          { text: "☎️ Gsm Detay Sorgu", callback_data: "/detgsm" }
        ],
        [
          { text: "📞 Gsm Tc Sorgu", callback_data: "/gsm" },
          { text: "📞 Tc Gsm Sorgu", callback_data: "/tcgsm" }
        ],
        [
          { text: "💊 Randevu Sorgu", callback_data: "/randevu" },
          { text: "*️⃣ Operatör Sorgu", callback_data: "/operat" }
        ],
        [
          { text: "🈴 Mahalle sorgu", callback_data: "/mahalle" },
          { text: "🛖 Hane Sorgu", callback_data: "/adres" }
        ],
        [
          { text: "📍 Adres Sorgu", callback_data: "/adress" },
          { text: "🆘 Hayat Hikâye S.", callback_data: "/hikaye" }
        ],
        [
          { text: "👣 Ayak Sorgu", callback_data: "/ayakk" },
          { text: "📏 Cm Ölçer", callback_data: "/cm" }
        ],
        [
          { text: "🧑‍💻 İmei Sorgu", callback_data: "/ime" },
          { text: "🌐 Sub domain S.", callback_data: "/sub" }
        ],
        [
          { text: "🛜 Domain Sorgu", callback_data: "/dom" },
          { text: "*️⃣ Dns Sorgu", callback_data: "/dns" }
        ],
        [
          { text: "📝 Deftere yazı yazma", callback_data: "/defter" }
        ],
        /*[
          { text: "🚘 Ehliyet Vesika Sorgu", web_app: { url: AppURL } }
        ],*/
        [
          { text: "🔏 Python Encode & Decode", web_app: { url: enc } }
        ]
      ]
    }
  });
}
