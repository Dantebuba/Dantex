/*CMD
  command: /bak
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu2
  answer: *- Bu komut bakımdadır*

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

