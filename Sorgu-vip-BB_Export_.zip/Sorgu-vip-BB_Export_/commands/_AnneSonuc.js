/*CMD
  command: /AnneSonuc
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

try {
  let anneData = JSON.parse(content);
  User.setProperty("anneSonuc", anneData, "json");
} catch (e) {
  Bot.sendMessage("❌ Anne verisi alınamadı.");
}
Bot.runCommand("/tcSonuc");
