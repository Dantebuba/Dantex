/*CMD
  command: /tcSonuc
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let numara = User.getProperty("sonNumara");
let anneData = User.getProperty("anneSonuc");
let babaData = User.getProperty("babaSonuc");

if (anneData && babaData) {
  let anne = anneData["Kişi Bilgileri"];
  let baba = babaData["Kişi Bilgileri"];
  let babaKisi = {
    ADI: baba.ADI || baba.AD || "—",
    SOYADI: baba.SOYADI || baba.SOYAD || "—",
    TC: baba.TC || "—",
    DOĞUMTARIHI: baba.DOĞUMTARIHI || "—",
    YAŞ: baba.YAŞ || "—",
    IL: baba.NUFUSIL || baba.MEMLEKETIL || "—",
    ILCE: baba.NUFUSILCE || baba.MEMLEKETILCE || "—",
    BABA_ADI: baba.BABAADI || "—",
    BABA_TC: baba.BABATC || "—",
    BABA_DOĞUMTARIHI: baba.BABA_DOĞUMTARİHİ || "—",
    BABA_YAS: baba.BABA_YAŞ || "—"
  };
  let anneKisi = {
    ADI: anne.ANNE_ADI || "—",
    SOYADI: anne.SOYADI || anne.SOYAD || "—",
    TC: anne.ANNE_TC || "—",
    DOĞUMTARIHI: anne.ANNE_DOĞUMTARİHİ || "—",
    YAŞ: anne.ANNE_YAŞ || "—",
    IL: anne.MEMLEKETIL || anne.NUFUSIL || "—",
    ILCE: anne.MEMLEKETILCE || anne.NUFUSILCE || "—"
  };
  let sonuc =
`*📡 Sorgu Sonucu (${numara}):

---------------
- ADI: ${babaKisi.ADI}
- SOYADI: ${babaKisi.SOYADI}
- TC: ${babaKisi.TC}
- DOĞUM TARİHİ: ${babaKisi.DOĞUMTARIHI}
- YAŞ: ${babaKisi.YAŞ}
- NÜFUS İL: ${babaKisi.IL}
- NÜFUS İLÇE: ${babaKisi.ILCE}
- BABA ADI: ${babaKisi.BABA_ADI}
- BABA TC: ${babaKisi.BABA_TC}
- BABA DOĞUM TARİHİ: ${babaKisi.BABA_DOĞUMTARIHI}
- BABA YAŞ: ${babaKisi.BABA_YAS}
- ANNE ADI: ${anneKisi.ADI}
- ANNE SOYADI: ${anneKisi.SOYADI}
- TC: ${anneKisi.TC}
- ANNNE DOĞUM TARİHİ: ${anneKisi.DOĞUMTARIHI}
- ANNNE YAŞ: ${anneKisi.YAŞ}
- ANNE MEMLEKET İL: ${anneKisi.IL}
- ANNE MEMLEKET İLÇE: ${anneKisi.ILCE}
---------------*`;

  Bot.sendMessage(sonuc, { parse_mode: "Markdown" });
  User.setProperty("anneSonuc", null);
  User.setProperty("babaSonuc", null);
}
