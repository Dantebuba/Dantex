/*CMD
  command: /start
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Kanal Katılım - Check
  answer: *- Bot Taşındı Yeni Botu @QueryBots Kanalından Ulaşabilirsiniz*

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

