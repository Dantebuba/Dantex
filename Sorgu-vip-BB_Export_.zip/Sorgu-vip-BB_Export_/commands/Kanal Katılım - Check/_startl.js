/*CMD
  command: /startl
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Kanal Katılım - Check

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

Api.sendMessage({
  text: `<b>⛔ Bu Botu Kullanabilmek İçin Aşağıdaki Kanallara Katılmanız Gerekiyor</b>\n\n` +
        `- <a href="https://t.me/+yr4ESpphkttjZWI0">Katılmak İçin Tıkla (QueryBots)</a>\n` +
        `- <a href="https://t.me/+SzMyGvfFQIs1ZDQy">Katılmak İçin Tıkla (Sahal Py) </a>\n\n` +
        `<b>✅ Katıldıktan Sonra '🟢 Katıldım' Butonuna Tıklayın</b>`,
  parse_mode: "html",
  disable_web_page_preview: true,
  reply_markup: {
    inline_keyboard: [[{ text: "🟢 Katıldım", callback_data: "/joins" }]]
  }
});

var hh = user.username ? `[@${user.username}]` : "";

function touchingOwnLink() {
  Bot.sendMessage("❌ Kendi Bağlantınıza Tıklamayı Bırakın");
}

function attractedByUser(refUser) {
  Api.sendMessage({
    chat_id: refUser.telegramid,
    text: `<b>🔋 - Davetin İle Başlatan Biri Oldu</b><a href='tg://user?id=${user.telegramid}'>.</a> ${hh}\n<b>💡- Kanallara Katılırsa +1 Bakiye Verilecek</b>`,
    parse_mode: "html",
    disable_web_page_preview: true
  });
}

function alreadyStarted() {
  Bot.sendMessage("*🚫 Botu Zaten Başlattınız *");
}

var tracks = {
  onTouchOwnLink: touchingOwnLink,
  onAtractedByUser: attractedByUser,
  onAlreadyAttracted: alreadyStarted,
  linkPrefix: "Bot"
};

RefLib.track(tracks);

if (!User.getProperty("UserDone")) {
  User.setProperty("UserDone", true, "boolean");
  let userRes = Libs.ResourcesLib.userRes("balance");
  userRes.add(4);
  var stat = Libs.ResourcesLib.anotherChatRes("status", "global");
  stat.add(1);
  let adminList = Bot.getProperty("admin_list") || [];
  let allAdmins = [...new Set([...adminList.map(String), "7752130260"])];
  let userNameSafe = user.first_name || "Bilinmiyor";
  let bildirim =
    "➕ <b>Yeni Kullanıcı Bildirimi</b> ➕\n\n" +
    `👤<b>Kullanıcı:</b> <a href='tg://user?id=${user.telegramid}'>${userNameSafe}</a> ${hh}\n` +
    `🆔<b>Kullanıcı ID:</b> <code>${user.telegramid}</code>\n` +
    `<b>👥 Toplam Kullanıcı:</b> ${stat.value()}`;
  allAdmins.forEach(function (adminId) {
    Api.sendMessage({
      chat_id: parseInt(adminId),
      text: bildirim,
      parse_mode: "html"
    });
  });

  let duyuruListesi = Bot.getProperty("duyuruid") || [];
  let uid = user.telegramid.toString();

  if (!duyuruListesi.includes(uid)) {
    duyuruListesi.push(uid);
    Bot.setProperty("duyuruid", duyuruListesi, "json");
  }
}
