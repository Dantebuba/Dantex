/*CMD
  command: /joins
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Kanal Katılım - Check

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let stat = Bot.getProperty(""+user.telegramid+"?Ban");

if (stat=="ban"){
  Bot.sendMessage("*Botu Kullanmanız Yasaklandı ❌*");
}else{
  let channel = "-1002333007570"; // sahal py 
  let id = user.telegramid
  Api.getChatMember({ 
    chat_id : channel,
    user_id : id,
    on_result :"/check0"
  })
}
