/*CMD
  command: /check0
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Kanal Katılım - Check

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var user = options.result.status
if ((user == "member") | (user == "administrator") | (user == "creator")) {
  User.setProperty("userStatus", user, "string")
  Bot.runCommand("join2")
}

if (user == "left") {
  Bot.sendMessage("*⚠️ Tüm Kanallarımıza Katılmalısınız*")
}
