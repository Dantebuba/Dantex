/*CMD
  command: !
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

var text = "*⚠️ Olası Bir Hata Oluştu Oluşma Nedenleri Bunlar Olabilir;*\n\n- Bitişik Yazılmayan *TC ve GSM *Numaraları\n- Geçersiz *Uzun* Yazılan Parametreler\n- Oluşan Spamdan Dolayı *Apinin Geçersiz Yanıtı*\n\n✳️ Devam Eden Olası Hatalar İçin *Destek Ekibine Bildirin* (Alttaki Kanaldan Ulaşabilirsiniz)";

var buttons = [
  [
    {title: "📮 Support Channel", url: "https://t.me/QueryBots"}
  ]
];

Bot.sendInlineKeyboard(buttons, text);
let adminId = 7752130260;
let userName = user.first_name || "Bilinmeyen Kullanıcı";
let userId = user.telegramid;

let adminText = `🚨 <b>Hey patron!</b> Kullanıcı <a href="tg://user?id=${userId}">${userName}</a> botta bir hata aldı. Lütfen hatalar kısmını kontrol et.`;

Api.sendMessage({
  chat_id: adminId,
  text: adminText,
  parse_mode: "html"
});
