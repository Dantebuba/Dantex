/*CMD
  command: /TcS
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let anneBilgi = User.getProperty("anneBilgi");
let babaBilgi = User.getProperty("babaBilgi");

let numara = User.getProperty("sonNumara");

let dataText = "*📡 Sorgu Sonucu (" + numara + "):*\n\n";
dataText += "---------------\n";
let ortakAlanlar = ["ADI", "SOYADI", "TC", "DOĞUMTARIHI", "YAŞ", "NUFUSIL", "NUFUSILCE"];
ortakAlanlar.forEach(key => {
  let temizKey = key.replace(/_/g, " ").toUpperCase();
  let deger = babaBilgi[key] ? babaBilgi[key] : "—";
  dataText += "- " + temizKey + ": " + deger + "\n";
});
dataText += "- BABAADI: " + (babaBilgi["BABAADI"] || "—") + "\n";
dataText += "- BABATC: " + (babaBilgi["BABATC"] || "—") + "\n";
dataText += "- BABA DOĞUMTARİHİ: " + (babaBilgi["BABA DOĞUMTARİHİ"] || "—") + "\n";
dataText += "- BABA YAŞ: " + (babaBilgi["BABA YAŞ"] || "—") + "\n";
dataText += "- ANNE ADI: " + (anneBilgi["ANNE ADI"] || "—") + "\n";
dataText += "- ANNE TC: " + (anneBilgi["ANNE TC"] || "—") + "\n";
dataText += "- ANNE DOĞUMTARİHİ: " + (anneBilgi["ANNE DOĞUMTARİHİ"] || "—") + "\n";
dataText += "- ANNE YAŞ: " + (anneBilgi["ANNE YAŞ"] || "—") + "\n";

dataText += "---------------";

Bot.sendMessage(dataText, { parse_mode: "Markdown" });
User.setProperty("anneBilgi", null);
User.setProperty("babaBilgi", null);
