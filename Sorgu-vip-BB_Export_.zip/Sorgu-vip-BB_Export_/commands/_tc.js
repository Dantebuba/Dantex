/*CMD
  command: /tc
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 
  answer: *🪪 Tc Sorgu için TC girin:*

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

// Kullanıcıdan gelen TC
let numara = message;

// Eğer mesaj 11 haneli rakam değilse uyar
if (!/^\d{11}$/.test(numara)) {
  Bot.sendMessage("❌ Geçersiz numara! Lütfen 11 haneli bir sayı giriniz.");
  return;
}

// TC'yi kaydet
User.setProperty("sonNumara", numara, "string");

// Anne API'sini çağır
HTTP.get({
  url: "https://api.zahin.net/apiler/anne.php?tc=" + numara,
  success: "/AnneSonuc"
});

// Baba API'sini çağır
HTTP.get({
  url: "https://api.zahin.net/apiler/baba.php?tc=" + numara,
  success: "/BabaSonuc"
});
