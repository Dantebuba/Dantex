/*CMD
  command: /adress1
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}

if (response.success && response.data && response.data.length > 0) {
  let kisi = response.data[0];

  let sonuc = `📋 *Kişi Bilgileri\n\n` +
              `🆔 ID: ${kisi.id || "—"}\n` +
              `🪪 TC: ${kisi.tc || "—"}\n` +
              `👤 Ad Soyad: ${kisi.ad_soyad || "—"}\n` +
              `📍 Doğum Yeri: ${kisi.dogum_yeri || "—"}\n` +
              `💳 Vergi No: ${kisi.vergi_numarasi || "—"}\n` +
              `🏠 Adres: ${kisi.adres || "—"}\n` +
              `🏙️ Nüfus İl: ${kisi.nufus_il || "—"}\n` +
              `🏘️ Nüfus İlçe: ${kisi.nufus_ilce || "—"}\n\n` +
              `⏱️ Sorgu Süresi: ${response.sorgu_suresi || "—"}*\n`;

  Bot.sendMessage(sonuc, { parse_mode: "Markdown" });
} else {
  Bot.sendMessage("❌ Veri bulunamadı.");
}
