/*CMD
  command: /DuzSONUC
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;

try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}

if (response["Kişi Bilgileri"]) {
  let kisi = response["Kişi Bilgileri"];
  let dataText = "";

  for (let key in kisi) {
    let temizKey = key.replace(/_/g, " ");
    dataText += "*- " + temizKey + ":* `" + kisi[key] + "`\n";
  }
  Bot.sendMessage(
    "*📡 Sorgu Sonucu (*`" + User.getProperty("sonNumara") + "`):\n\n*---------------*\n" +
    dataText + "*---------------*" ,
    { parse_mode: "Markdown" }
  );
} else {
  Bot.sendMessage("❌ Kişi bilgileri bulunamadı.");
}
