/*CMD
  command: /cm1
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}
if (response.success && response.data) {
  let cm = response.data.cm || "—";

  let sonuc = `📏 Ölçü Sonucu: ${cm}`;

  Bot.sendMessage(sonuc);
} else {
  Bot.sendMessage("❌ Veri bulunamadı.");
}
