/*CMD
  command: /dom1
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}

if (response.durum === "basarili" && response.veri) {
  const veri = response.veri;

  const domain = veri.domain_adi || "—";
  const kayitci = veri.kayitci || "—";
  const olusturma = veri.olusturma_tarihi || "—";
  const bitis = veri.bitis_tarihi || "—";
  const isimSunuculari = veri.isim_sunuculari || [];
  const hamVeri = veri.ham_veri || "—";

  let nsList = isimSunuculari.length > 0 
    ? isimSunuculari.map((d, i) => `${i + 1}. ${d}`).join("\n") 
    : "—";

  let infoMesaj = response.info?.mesaj || "";

  let sonuc = 
`✅ WHOIS Sorgu Başarılı

🌐 Domain: ${domain}
🏢 Kayıtçı: ${kayitci}
📅 Oluşturulma Tarihi: ${olusturma}
📅 Bitiş Tarihi: ${bitis}

🖥️ İsim Sunucuları:
${nsList}`;

  Bot.sendMessage(sonuc);

} else {
  Bot.sendMessage("❌ Veri bulunamadı.");
}
