/*CMD
  command: /hikaye
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Menu 
  answer: 🆘* Hayat Hikâye sorgu için TC girin:*

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let numara = message;
if (!/^\d{11}$/.test(numara)) {
  Bot.sendMessage("❌ Geçersiz numara! Lütfen 11 haneli bir sayı giriniz.");
  return;
}

User.setProperty("sonNumara", numara, "string");
HTTP.get({
  url: "https://keneviz.kolsuzpabg.workers.dev/hayat_hikayesi?tc=" + numara,
  success: "/hikaye1"
});
