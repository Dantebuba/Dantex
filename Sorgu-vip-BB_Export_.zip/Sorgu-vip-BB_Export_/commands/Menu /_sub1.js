/*CMD
  command: /sub1
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content); // API cevabını parse et
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}
if (response.success === true) {
  let sure = response.sorgu_suresi || "—";
  let info = response.info || {};
  let mesaj = info.mesaj || "";
  let dataList = response.data || [];
  let domainler = dataList.length > 0 
    ? dataList.map((d, i) => `${i + 1}. ${d}`).join("\n")
    : "—";

  let sonuc = 
`✅ Sorgu Başarılı
⏱ Sorgu Süresi: ${sure}

🌍 Domainler:
${domainler}`;

  Bot.sendMessage(sonuc);

} else {
  Bot.sendMessage("*❌ Veri bulunamadı.*");
}
