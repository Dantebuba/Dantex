/*CMD
  command: /kuz2
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;

try {
  response = JSON.parse(content); 
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}
let dataText = "*📡 Sorgu Sonucu (" + User.getProperty("sonNumara") + "):*\n\n";
if (response["kendisi"] && response["kendisi"].length > 0) {
  response["kendisi"].forEach((kisi, index) => {
    dataText += "*📌 Kişi " + (index + 1) + " (Kendisi)*\n";
    for (let key in kisi) {
      let temizKey = key.replace(/_/g, " ");
      let deger = kisi[key] ? kisi[key] : "—";
      dataText += "**" + temizKey + ":** `" + deger + "`\n";
    }
    dataText += "\n*---------------*\n\n";
  });
} else {
  dataText += "❌ Kendisi bilgileri bulunamadı.\n";
}
if (response["anne_tarafi_kuzenler"] && response["anne_tarafi_kuzenler"].length > 0) {
  response["anne_tarafi_kuzenler"].forEach((kisi, index) => {
    dataText += "*📌 Kişi " + (index + 1) + " (Kuzen - Anne Tarafı)*\n";

    for (let key in kisi) {
      let temizKey = key.replace(/_/g, " ");
      let deger = kisi[key] ? kisi[key] : "—";
      dataText += "**" + temizKey + ":** `" + deger + "`\n";
    }
    dataText += "\n*---------------*\n\n";
  });
} else {
  dataText += "❌ Anne tarafı kuzenler bilgileri bulunamadı.\n";
}
if (response["baba_tarafi_kuzenler"] && response["baba_tarafi_kuzenler"].length > 0) {
  response["baba_tarafi_kuzenler"].forEach((kisi, index) => {
    dataText += "*📌 Kişi " + (index + 1) + " (Kuzen - Baba Tarafı)*\n";

    for (let key in kisi) {
      let temizKey = key.replace(/_/g, " ");
      let deger = kisi[key] ? kisi[key] : "—";
      dataText += "**" + temizKey + ":** `" + deger + "`\n";
    }
    dataText += "\n*---------------*\n\n";
  });
} else {
  dataText += "❌ Baba tarafı kuzenler bilgileri bulunamadı.\n";
}
const maxLength = 4096;
let currentMessage = dataText.slice(0, maxLength);
Bot.sendMessage(currentMessage, { parse_mode: "Markdown" });
let remainingMessage = dataText.slice(maxLength);
if (remainingMessage.length > 0) {
  Bot.sendMessage(remainingMessage, { parse_mode: "Markdown" });
}
