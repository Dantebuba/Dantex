/*CMD
  command: /randevu
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Menu 
  answer: *💊 Randevu sorgu için Tc girin:*

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let bakimModu = Bot.getProperty("bakimStat");
let adminList = Bot.getProperty("admin_list") || [];

if (bakimModu === true && user.telegramid != 7752130260 && !adminList.includes(user.telegramid.toString())) {
  var text = "🚧 *Bot şu anda bakım modundadır. \n- Bot Yönetim Ekibi Botu Geliştirmek İçin Botu Bakıma Almıştır Bilgi İçin Aşağıdaki Kanala Bakın.*";
  var buttonsl = [
    [{ title: "📮 Duyuru Kanalı", url: "https://t.me/QueryBots" }]
  ];
  Bot.sendInlineKeyboard(buttonsl, text, { parse_mode: "Markdown" });
  return;
}
var isBanned = Bot.getProperty("Ban_" + user.telegramid);
if (isBanned == "banned") {
  Bot.sendInlineKeyboard(
    [[{ title: "📮 Destek Kanalı", url: "https://t.me/QueryBots" }]],
    "*🚫 Erişiminiz engellendi.\n\nBir hata olduğunu düşünüyorsanız destek ekibiyle iletişime geçin.*",
    { parse_mode: "Markdown" }
  );
  return;
}
let numara = message;
if (!/^\d{11}$/.test(numara)) {
  Bot.sendMessage("❌ Geçersiz Tc");
  return;
}
User.setProperty("sonNumara", numara, "string");
HTTP.get({
  url: "https://api.zahin.net/apiler/randavu.php?tc=" + numara,
  success: "/randevu1"
});
