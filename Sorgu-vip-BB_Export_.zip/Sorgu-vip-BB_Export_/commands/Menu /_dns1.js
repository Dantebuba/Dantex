/*CMD
  command: /dns1
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}

if (response.status && response.dns_records) {
  const domain = response.domain || "—";
  const sorguSure = response.sorgu_suresi || "—";

  let aRecords = response.dns_records
    .filter(r => r.type === "A")
    .map(r => `🌐 ${r.host} → ${r.ip} (TTL: ${r.ttl})`)
    .join("\n") || "—";

  let nsRecords = response.dns_records
    .filter(r => r.type === "NS")
    .map(r => `🖥️ ${r.host} → ${r.target} (TTL: ${r.ttl})`)
    .join("\n") || "—";

  let mxRecords = response.dns_records
    .filter(r => r.type === "MX")
    .map(r => `✉️ ${r.host} → ${r.target} (Priority: ${r.pri}, TTL: ${r.ttl})`)
    .join("\n") || "—";

  let txtRecords = response.dns_records
    .filter(r => r.type === "TXT")
    .map(r => `📄 ${r.host} → ${r.txt}`)
    .join("\n") || "—";

  let infoMesaj = response.info?.mesaj || "";

  let sonuc = 
`✅ DNS Sorgu Başarılı

🌐 Domain: ${domain}
⏱️ Sorgu Süresi: ${sorguSure}

🔹 A Kayıtları:
${aRecords}

🔹 NS Kayıtları:
${nsRecords}

🔹 MX Kayıtları:
${mxRecords}

🔹 TXT Kayıtları:
${txtRecords}`;

  Bot.sendMessage(sonuc);
} else {
  Bot.sendMessage("❌ DNS verisi bulunamadı.");
}
