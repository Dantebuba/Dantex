/*CMD
  command: /vesika1
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}

if (response.success && response.data && response.data.VESİKA) {
  let base64img = response.data.VESİKA;
  Api.sendPhoto({
    chat_id: user.telegramid,
    photo: "data:image/jpeg;base64," + base64img,
    caption: "📸 Vesika Fotoğrafı"
  });
} else {
  Bot.sendMessage("❌ Vesika bulunamadı.");
}
