/*CMD
  command: /mahalle
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Menu 
  answer: *🈴 Mahalle sorgu için TC girin:*

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let numara = message;
User.setProperty("sonNumara", numara, "string");

HTTP.get({
  url: "https://api.zahin.net/apiler/mahalle.php?tc=" + numara,
  success: "/mahallee"
}); 
