/*CMD
  command: /GsmDet
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("*❌ API geçersiz yanıt verdi*.");
  return;
}

if (response.success && response.Data) {
  let data = response.Data;
  let msg = "*👤 TC Kimlik Bilgileri*\n\n";
  msg += "- *TC:* " + (data.TC || "—") + "\n";
  msg += "- *Ad:* " + (data.AD || "—") + "\n";
  msg += "- *Soyad:* " + (data.SOYAD || "—") + "\n";
  msg += "- *Doğum Tarihi:* " + (data.DOGUMTARIHI || "—") + "\n";
  msg += "- *Cinsiyet:* " + (data.CINSIYET || "—") + "\n";
  msg += "- *Anne Adı:* " + (data.ANNEADI || "—") + "\n";
  msg += "- *Anne TC:* " + (data.ANNETC || "—") + "\n";
  msg += "- *Baba Adı:* " + (data.BABAADI || "—") + "\n";
  msg += "- *Baba TC:* " + (data.BABATC || "—") + "\n";
  msg += "- *Adres İl:* " + (data.ADRESIL || "—") + "\n";
  msg += "- *Adres İlçe:* " + (data.ADRESILCE || "—") + "\n";
  msg += "- *İkametgah:* " + (data.Ikametgah || "—") + "\n";
  msg = msg.substring(0, 4090);

  Bot.sendMessage(msg, { parse_mode: "Markdown" });
} else {
  Bot.sendMessage("*❌ Geçerli bir veri bulunamadı.*");
}
