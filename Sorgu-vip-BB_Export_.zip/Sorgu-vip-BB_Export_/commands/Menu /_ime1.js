/*CMD
  command: /ime1
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content); // API cevabını parse ediyoruz
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}

if (response.success === true) {
  let cm = response.message || "—";
  let sonuc = `- Sonucu: ${cm}`;
  Bot.sendMessage(sonuc);

} else if (response.success === false) {
  let hata = response.message || "❌ Bilinmeyen hata.";
  Bot.sendMessage(`❌ Hata: ${hata}`);

} else {
  Bot.sendMessage("⚠️ API beklenmeyen formatta cevap verdi.");
}
