/*CMD
  command: /AileS
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;

try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}

if (response["data"] && response["data"].length > 0) {
  let kisiler = response["data"];
  let dataText = "*📡 Ad Soyad Sorgu Sonucu (" + User.getProperty("sonNumara") + "):*\n\n";
  kisiler.forEach((kisi, index) => {
    dataText += "*📌 Kişi " + (index + 1) + "*\n";
    for (let key in kisi) {
      if (key === "GSM" && kisi[key]) {
        dataText += "**" + key.replace(/_/g, " ") + ":** `" + kisi[key] + "`\n";
      } else if (kisi[key]) {
        let temizKey = key.replace(/_/g, " ");
        dataText += "*" + temizKey + ":* `" + kisi[key] + "`\n";
      } else {
        dataText += "*" + key.replace(/_/g, " ") + ":* `—`\n";
      }
    }

    dataText += "\n*---------------*\n\n";
  });

  Bot.sendMessage(dataText, { parse_mode: "Markdown" });
} else {
  Bot.sendMessage("❌ Kişi bilgileri bulunamadı.");
}
