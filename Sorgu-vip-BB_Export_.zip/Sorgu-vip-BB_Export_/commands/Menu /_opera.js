/*CMD
  command: /opera
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content); 
} catch (e) {
  Bot.sendMessage("*❌ API geçersiz yanıt verdi*.");
  return;
}
if (response.success && response.data) {
  let data = response.data;
  let msg = "*📱 Telefon Bilgisi*\n\n";
  msg += "- *Telefon:* " + (data.phone || "—") + "\n";
  msg += "- *Operatör:* " + (data.operator || "—") + "\n";
  msg = msg.substring(0, 4090);
  Bot.sendMessage(msg, { parse_mode: "Markdown" });
} else {
  Bot.sendMessage("*❌ Geçerli telefon bilgisi bulunamadı.*");
}
