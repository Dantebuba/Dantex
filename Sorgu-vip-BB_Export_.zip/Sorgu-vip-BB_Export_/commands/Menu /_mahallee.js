/*CMD
  command: /mahallee
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}
if (response.success && response.kisi) {
  let k = response.kisi;

  let sonuc =
"📡 Adres Sorgu (" + response.tc + ")\n\n" +
"👤 Kişi Bilgileri\n" +
"- Kimlik No: " + (k.KimlikNo || "—") + "\n" +
"- Ad Soyad: " + (k.AdSoyad || "—") + "\n" +
"- Doğum Yeri: " + (k.DogumYeri || "—") + "\n" +
"- Vergi Numarası: " + (k.VergiNumarasi || "—") + "\n" +
"- İkametgah: " + (k.Ikametgah || "—");

  Bot.sendMessage(sonuc);
} else {
  Bot.sendMessage("❌ Kişi bilgisi bulunamadı.");
}
