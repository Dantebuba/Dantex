/*CMD
  command: /aile
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Menu 
  answer: - 

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let numara = message;
if (!/^\d{11}$/.test(numara)) {
  Bot.sendMessage("❌ Geçersiz numara! Lütfen 11 haneli bir sayı giriniz.");
  return;
}
User.setProperty("sonNumara", numara, "string");

HTTP.get({
  url: "https://api.zahin.net/apiler/ailepro.php?tc=" + numara,
  success: "/AileS"
});
