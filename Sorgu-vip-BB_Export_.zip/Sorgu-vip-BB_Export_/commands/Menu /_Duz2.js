/*CMD
  command: /Duz2
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

// /DuzSONUC Komutu
let response;

try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}

if (response["data"] && response["data"].length > 0) {
  let kisi = response["data"][0];
  let dataText = "*📡 Ad Soyad Sorgu Sonucu (" + User.getProperty("sonNumara") + "):*\n\n";

  for (let key in kisi) {
    let temizKey = key.replace(/_/g, " ");  
    let deger = kisi[key] ? kisi[key] : "—";  
    dataText += "**" + temizKey + ":** `" + deger + "`\n";
  }

  let mesaj = dataText;
  if (mesaj.length > 4090) {
    mesaj = mesaj.substring(0, 4000); 
    mesaj += "\n\n*⚠️ Not: Sonucun yalnızca ilk 4000 karakteri gösterilmektedir.*";
  }

  Bot.sendMessage(mesaj, { parse_mode: "Markdown" });

} else {
  Bot.sendMessage("-");
}
