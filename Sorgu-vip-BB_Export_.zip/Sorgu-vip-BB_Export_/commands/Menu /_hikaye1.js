/*CMD
  command: /hikaye1
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}

if (response.success) {
  let hikaye = response.hikaye || "—";
  let sorguSure = response.meta?.sorgu_suresi || "—";
  let kaynak = response.meta?.kaynak || "—";

  let sonuc = `*${hikaye}\n\n⏱️ Sorgu Süresi: ${sorguSure}*`;

  Bot.sendMessage(sonuc, { parse_mode: "Markdown" });
} else {
  let hataMesaj = response.message || "❌ Veri bulunamadı.";
  Bot.sendMessage(hataMesaj);
}
