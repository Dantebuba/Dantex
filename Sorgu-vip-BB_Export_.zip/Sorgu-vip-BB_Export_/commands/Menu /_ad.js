/*CMD
  command: /ad
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Menu 
  answer: *- Sorgu için “Ad soyad il ilce” şeklinde girin:*

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let bakimModu = Bot.getProperty("bakimStat");
let adminList = Bot.getProperty("admin_list") || [];
if (bakimModu === true && user.telegramid != 7752130260 && !adminList.includes(user.telegramid.toString())) {
  var text = "🚧 *Bot şu anda bakım modundadır. \n- Bot Yönetim Ekibi Botu Geliştirmek İçin Botu Bakıma Almıştır Bilgi İçin Aşağıdaki Kanala Bakın.*";
  var buttonsl = [
    [{ title: "📮 Duyuru Kanalı", url: "https://t.me/QueryBots" }]
  ];
  Bot.sendInlineKeyboard(buttonsl, text, { parse_mode: "Markdown" });
  return;
}
var isBanned = Bot.getProperty("Ban_" + user.telegramid);
if (isBanned == "banned") {
  Bot.sendInlineKeyboard(
    [[{ title: "📮 Destek Kanalı", url: "https://t.me/QueryBots" }]],
    "*🚫 Erişiminiz engellendi.\n\nBir hata olduğunu düşünüyorsanız destek ekibiyle iletişime geçin.*",
    { parse_mode: "Markdown" }
  );
  return;
}
let userMessage = message.trim();  
let parts = userMessage.split(" ");  
if (parts.length < 2) {
  Bot.sendMessage("*❌ Lütfen bilgilerinizi doğru formatta girin.\nÖrnek: Mehmet Kavuran*");
  return;
}
let ad = parts[0];
let soyad = parts[1];
if (parts.length > 2) {
  ad = parts[0] + " " + parts[1];  // ad = Mehmet Emin
  soyad = parts[2];                // soyad = Kavuran
}
let apiUrl = "https://api.zahin.net/apiler/adsoyad.php?ad=" + encodeURIComponent(ad) + "&soyad=" + encodeURIComponent(soyad);

HTTP.get({
  url: apiUrl,
  success: "/Duz1"
});
