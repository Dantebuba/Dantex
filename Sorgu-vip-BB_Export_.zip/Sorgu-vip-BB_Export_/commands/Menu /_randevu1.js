/*CMD
  command: /randevu1
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("*❌ API geçersiz yanıt verdi*.");
  return;
}
let dataText = "*📅 Randevu Listesi*\n\n";
if (response.appointments && response.appointments.length > 0) {
  response.appointments.forEach((randevu, index) => {
    dataText += "*📌 Randevu " + (index + 1) + "*\n";
    dataText += "- *Randevu Durumu:* " + (randevu["Randevu Durumu"] || "—") + "\n";
    dataText += "- *Randevu Sahibi:* " + (randevu["Randevu Sahibi"] || "—") + "\n";
    dataText += "- *Randevu Tarihi:* " + (randevu["Randevu Tarihi"] || "—") + "\n";
    dataText += "- *Randevu Türü:* " + (randevu["Randevu Türü"] || "—") + "\n";
    dataText += "- *Randevu Yeri:* " + (randevu["Randevu Yeri"] || "—") + "\n";
    dataText += "*---------------*\n";
  });
} else {
  dataText += "*❌ Randevu bulunamadı ya da geçersiz API yanıtı*\n";
}
let limitedText = dataText.substring(0, 4090);
Bot.sendMessage(limitedText, { parse_mode: "Markdown" });
