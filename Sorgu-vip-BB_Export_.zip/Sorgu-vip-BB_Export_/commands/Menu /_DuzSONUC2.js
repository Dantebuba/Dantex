/*CMD
  command: /DuzSONUC2
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;

try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}

if (response["data"] && response["data"].length > 0) {
  let kisiler = response["data"];
  let sonucText = "*📡 Sorgu Sonucu (`" + User.getProperty("sonNumara") + "`):*\n\n";

  kisiler.forEach((kisi, index) => {
    sonucText += "*👤 Kişi " + (index + 1) + "*\n";

    for (let key in kisi) {
      let temizKey = key.replace(/_/g, " ");
      let deger = kisi[key] ? kisi[key] : "—";
      sonucText += "• *" + temizKey + ":* `" + deger + "`\n";
    }

    sonucText += "\n*---------------*\n\n";
  });

  Bot.sendMessage(sonucText, { parse_mode: "Markdown" });
} else {
  Bot.sendMessage("❌ Kişi bilgileri bulunamadı.");
}
