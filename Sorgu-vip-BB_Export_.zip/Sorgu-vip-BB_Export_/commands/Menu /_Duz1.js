/*CMD
  command: /Duz1
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let responseData = JSON.parse(content);  // API’den gelen JSON
let numara = responseData.data[0].TC;

// Dosya içeriğini hazırlayalım, okunabilir formatta
let fileContent = `📄 Sorgu Sonucu (${numara})\n\n`;

responseData.data.forEach((kisi, index) => {
  fileContent += `👤 Kişi ${index + 1}\n`;
  fileContent += `- AD: ${kisi.AD || "—"}\n`;
  fileContent += `- SOYAD: ${kisi.SOYAD || "—"}\n`;
  fileContent += `- TC: ${kisi.TC || "—"}\n`;
  fileContent += `- GSM: ${kisi.GSM || "—"}\n`;
  fileContent += `- BABA ADI: ${kisi.BABAADI || "—"}\n`;
  fileContent += `- BABA TC: ${kisi.BABATC || "—"}\n`;
  fileContent += `- ANNE ADI: ${kisi.ANNEADI || "—"}\n`;
  fileContent += `- ANNE TC: ${kisi.ANNETC || "—"}\n`;
  fileContent += `- DOĞUM TARİHİ: ${kisi.DOGUMTARIHI || "—"}\n`;
  fileContent += `- ÖLÜM TARİHİ: ${kisi.OLUMTARIHI || "—"}\n`;
  fileContent += `- DOĞUM YERİ: ${kisi.DOGUMYERI || "—"}\n`;
  fileContent += `- MEMLEKET İL: ${kisi.MEMLEKETIL || "—"}\n`;
  fileContent += `- MEMLEKET İLÇE: ${kisi.MEMLEKETILCE || "—"}\n`;
  fileContent += `- MEMLEKET KÖY: ${kisi.MEMLEKETKOY || "—"}\n`;
  fileContent += `- ADRES İL: ${kisi.ADRESIL || "—"}\n`;
  fileContent += `- ADRES İLÇE: ${kisi.ADRESILCE || "—"}\n`;
  fileContent += `- AİLE SIRA NO: ${kisi.AILESIRANO || "—"}\n`;
  fileContent += `- BİREY SIRA NO: ${kisi.BIREYSIRANO || "—"}\n`;
  fileContent += `- MEDENİ HAL: ${kisi.MEDENIHAL || "—"}\n`;
  fileContent += `- CİNSİYET: ${kisi.CINSIYET || "—"}\n`;
  fileContent += `- 2023 Adres: ${kisi["2023Adres"] || "—"}\n`;
  fileContent += `- Vergi Numarası: ${kisi.VergiNumarasi || "—"}\n`;
  fileContent += `- GSM NUMARALARI: ${kisi.GSMNumbers ? kisi.GSMNumbers.join(", ") : "—"}\n`;
  fileContent += `---------------\n`;
});

// Dosyayı kullanıcıya gönder
Bot.sendDocument(fileContent, `SorguSonucu_${numara}.txt`);
