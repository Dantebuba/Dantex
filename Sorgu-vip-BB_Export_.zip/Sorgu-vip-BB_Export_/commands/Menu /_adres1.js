/*CMD
  command: /adres1
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Menu 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let response;
try {
  response = JSON.parse(content);
} catch (e) {
  Bot.sendMessage("❌ API geçersiz yanıt verdi.");
  return;
}

if (response.results && response.results.length > 0) {
  let mesaj = "📡 " + (response.api_ismi || "Sorgu Sonucu") + "\n\n";

  response.results.forEach((kisi, index) => {
    mesaj += "👤 *Kişi " + (index + 1) + "*\n" +
             "- Kimlik No: `" + (kisi.KimlikNo || "—") + "`\n" +
             "- Ad Soyad: `" + (kisi.AdSoyad || "—") + "`\n" +
             "- Doğum Yeri: `" + (kisi.DogumYeri || "—") + "`\n" +
             "- İkametgah: `" + (kisi.Ikametgah || "—") + "`\n\n";
  });

  Bot.sendMessage(mesaj, { parse_mode: "Markdown" });
} else {
  Bot.sendMessage("❌ Kişi bilgisi bulunamadı.");
}
